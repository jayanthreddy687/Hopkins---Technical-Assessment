Dataset: Sample PE Dataroom – “Highland Analytics Ltd” (fictional, Edinburgh, UK)
Created: 2025-10-16 (Europe/London)
Purpose: Provide realistic sample documents for testing PE due-diligence agents and features.
Notes: All names, figures, and facts are synthetic and for demonstration only.

Files in this pack:
  01_Executive_Summary.txt
  02_Financials_Quarterly_Extract.csv
  03_Customer_Concentration.csv
  04_Material_Contracts_Summary.txt
  05_IP_Register.csv
  06_HR_Schedule.csv
  07_IT_Security_Compliance.txt
  08_Debt_Schedule.csv
  09_Tax_Compliance_Summary.txt
  10_QA_Log_Excerpt.txt
  dataroom_manifest.json
